import './index.js'; // [moduleized]
